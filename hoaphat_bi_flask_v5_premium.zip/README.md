# Hòa Phát – Demo website PREMIUM v5 (Flask)
Nâng cấp: Dark mode, Chart.js cho BCTC, Export CSV, phân trang Tin/Sản phẩm, RSS, sitemap.

## Chạy nhanh
```bash
python -m venv venv
venv\Scripts\activate  # Windows
pip install -r requirements.txt
python app.py
```
- Trang: /, /gioi-thieu, /san-pham, /tin-tuc, /tuyen-dung, /lien-he, /bi, /bctc
- RSS: /rss.xml • Sitemap: /sitemap.xml
- Xuất CSV BCTC: /export/bctc/{balance_sheet|income_statement|cash_flow}?ticker=HPG&from=2019&to=2023
