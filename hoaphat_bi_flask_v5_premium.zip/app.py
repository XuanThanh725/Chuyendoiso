from flask import Flask, render_template, request, redirect, url_for, flash, send_file, Response
import pandas as pd, io, os, math
from pathlib import Path
import threading, webbrowser, time, datetime as dt

app = Flask(__name__)
app.secret_key = os.getenv("APP_SECRET", "hp-demo-secret")
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"

STATEMENT_FILES = {
    "balance_sheet": DATA_DIR / "balance_sheet.csv",
    "income_statement": DATA_DIR / "income_statement.csv",
    "cash_flow": DATA_DIR / "cash_flow.csv",
}
PRODUCTS_FILE = DATA_DIR / "products.csv"
NEWS_FILE = DATA_DIR / "news.csv"
JOBS_FILE = DATA_DIR / "jobs.csv"

SITE_NAME = "Hòa Phát GR – Demo"
SITE_DESC = "Website giới thiệu Hòa Phát – Giới thiệu, Sản phẩm, Tin tức, Tuyển dụng, Liên hệ. Kèm BI & Báo cáo tài chính."

# ----------------- helpers -----------------
def load_df(name: str) -> pd.DataFrame:
    df = pd.read_csv(STATEMENT_FILES[name])
    df.columns = [c.strip().lower() for c in df.columns]
    if "year" in df.columns:
        df["year"] = df["year"].astype(int)
    return df

def list_tickers() -> list:
    tickers = set()
    for k in STATEMENT_FILES:
        df = load_df(k)
        tickers.update(df["ticker"].str.upper().unique().tolist())
    return sorted(tickers)

def load_products() -> pd.DataFrame:
    df = pd.read_csv(PRODUCTS_FILE)
    df.columns = [c.strip().lower() for c in df.columns]
    for c in ["name","category","slug","desc"]:
        if c in df.columns:
            df[c] = df[c].astype(str)
    return df

def load_news() -> pd.DataFrame:
    df = pd.read_csv(NEWS_FILE, parse_dates=["date"])
    df.columns = [c.strip().lower() for c in df.columns]
    return df.sort_values("date", ascending=False)

def load_jobs() -> pd.DataFrame:
    df = pd.read_csv(JOBS_FILE)
    df.columns = [c.strip().lower() for c in df.columns]
    for c in ["title","dept","location","level","slug","jd"]:
        if c in df.columns:
            df[c] = df[c].astype(str)
    return df

def paginate(df: pd.DataFrame, page: int, per_page: int = 9):
    total = len(df)
    pages = max(1, math.ceil(total / per_page))
    page = max(1, min(page, pages))
    start = (page - 1) * per_page
    end = start + per_page
    return df.iloc[start:end], page, pages, total

# ----------------- routes -----------------
@app.route("/")
def index():
    years = sorted(set(load_df("income_statement")["year"].tolist()))
    return render_template("index.html",
        tickers=list_tickers(), years=years,
        title="Trang chủ", meta_desc=SITE_DESC)

@app.route("/gioi-thieu")
def gioi_thieu():
    timeline = [
        {"year": 1992, "title": "Thành lập doanh nghiệp", "desc": "Khởi đầu kinh doanh thép & vật liệu."},
        {"year": 2007, "title": "Niêm yết HPG", "desc": "Cổ phiếu chính thức giao dịch trên HOSE."},
        {"year": 2016, "title": "Mở rộng quy mô", "desc": "Đầu tư tổ hợp sản xuất công nghiệp."},
        {"year": 2020, "title": "Tự động hoá", "desc": "Ứng dụng công nghệ 4.0 vào vận hành."},
        {"year": 2025, "title": "Phát triển bền vững", "desc": "Tập trung ESG & chuỗi cung ứng xanh."},
    ]
    values = [
        {"icon":"🏗️","title":"Chất lượng","desc":"Chuẩn mực sản xuất & quản trị."},
        {"icon":"⏱️","title":"Kỷ luật","desc":"An toàn – đúng tiến độ – hiệu quả."},
        {"icon":"💡","title":"Sáng tạo","desc":"Cải tiến liên tục, công nghệ hiện đại."},
        {"icon":"🤝","title":"Trách nhiệm","desc":"Với khách hàng, cổ đông và xã hội."},
        {"icon":"🌱","title":"Bền vững","desc":"Giảm phát thải, kinh tế tuần hoàn."},
        {"icon":"👥","title":"Con người","desc":"Nhân sự là trọng tâm phát triển."},
    ]
    stats = [
        {"label":"Năm phát triển","value":"30+"},
        {"label":"Nhân sự","value":"20,000+"},
        {"label":"Nhà máy","value":"30+"},
        {"label":"Quốc gia xuất khẩu","value":"40+"},
    ]
    return render_template("gioi-thieu.html", title="Giới thiệu", stats=stats, values=values, timeline=timeline, meta_desc="Giới thiệu Hòa Phát – tầm nhìn, sứ mệnh, giá trị cốt lõi, lịch sử, văn hoá.")

@app.route("/san-pham")
def san_pham():
    df = load_products()
    cat = request.args.get("cat","").strip().lower()
    q = request.args.get("q","").strip().lower()
    page = int(request.args.get("page", 1))
    cats = df["category"].dropna().unique().tolist()

    filtered = df.copy()
    if cat:
        filtered = filtered[filtered["category"].str.lower()==cat]
    if q:
        filtered = filtered[filtered["name"].str.lower().str.contains(q) | filtered["desc"].str.lower().str.contains(q)]
    filtered, page, pages, total = paginate(filtered, page, per_page=9)

    return render_template("san-pham.html",
        title="Sản phẩm", cats=cats, cat=cat, q=q,
        items=filtered.to_dict(orient="records"),
        page=page, pages=pages, total=total,
        meta_desc="Danh mục sản phẩm Hòa Phát: thép, ống thép, tôn mạ, nội thất, điện lạnh...")

@app.route("/san-pham/<slug>")
def san_pham_detail(slug):
    df = load_products()
    row = df[df["slug"]==slug]
    if row.empty: return redirect(url_for("san_pham"))
    item = row.iloc[0].to_dict()
    related = df[(df["category"]==item["category"]) & (df["slug"]!=slug)].head(6).to_dict(orient="records")
    return render_template("san-pham-detail.html", title=item["name"], item=item, related=related, meta_desc=item["desc"][:150])

@app.route("/tin-tuc")
def tin_tuc():
    df = load_news()
    tag = request.args.get("tag","").strip().lower()
    q = request.args.get("q","").strip().lower()
    page = int(request.args.get("page", 1))
    tags = sorted(set([t for s in df["tags"].fillna("") for t in s.split("|") if t]))

    news = df.copy()
    if tag:
        news = news[news["tags"].fillna("").str.lower().str.contains(tag)]
    if q:
        news = news[news["title"].str.lower().str.contains(q) | news["excerpt"].str.lower().str.contains(q)]
    news, page, pages, total = paginate(news, page, per_page=9)
    return render_template("tin-tuc.html", title="Tin tức Tập đoàn", items=news.to_dict(orient="records"),
        tags=tags, tag=tag, q=q, page=page, pages=pages, total=total, meta_desc="Tin tức Tập đoàn Hòa Phát.")

@app.route("/tin-tuc/<slug>")
def tin_tuc_detail(slug):
    df = load_news()
    row = df[df["slug"]==slug]
    if row.empty: return redirect(url_for("tin_tuc"))
    item = row.iloc[0].to_dict()
    latest = df[df["slug"]!=slug].head(6).to_dict(orient="records")
    return render_template("tin-tuc-detail.html", title=item["title"], item=item, latest=latest, meta_desc=item["excerpt"][:150])

@app.route("/tuyen-dung")
def tuyen_dung():
    df = load_jobs()
    dept = request.args.get("dept","").strip().lower()
    location = request.args.get("location","").strip().lower()
    level = request.args.get("level","").strip().lower()

    jobs = df.copy()
    if dept: jobs = jobs[jobs["dept"].str.lower()==dept]
    if location: jobs = jobs[jobs["location"].str.lower()==location]
    if level: jobs = jobs[jobs["level"].str.lower()==level]

    depts = sorted(df["dept"].dropna().unique().tolist())
    locs  = sorted(df["location"].dropna().unique().tolist())
    levels= sorted(df["level"].dropna().unique().tolist())
    return render_template("tuyen-dung.html", title="Tuyển dụng", jobs=jobs.to_dict(orient="records"),
        depts=depts, locs=locs, levels=levels, dept=dept, location=location, level=level, meta_desc="Việc làm tại Tập đoàn Hòa Phát.")

@app.route("/tuyen-dung/<slug>")
def tuyen_dung_detail(slug):
    df = load_jobs()
    row = df[df["slug"]==slug]
    if row.empty: return redirect(url_for("tuyen_dung"))
    job = row.iloc[0].to_dict()
    return render_template("tuyen-dung-detail.html", title=job["title"], job=job, meta_desc=job["jd"][:150])

@app.route("/lien-he", methods=["GET","POST"])
def lien_he():
    if request.method == "POST":
        flash("Đã nhận liên hệ của bạn. Chúng tôi sẽ phản hồi sớm!")
        return redirect(url_for("lien_he"))
    return render_template("lien-he.html", title="Liên hệ", meta_desc="Liên hệ Hòa Phát.")

# -------- BI & BCTC + Export & Charts JS data endpoints ----------
@app.route("/bi")
def bi():
    return render_template("bi.html", title="Dashboard BI", meta_desc="Dashboard Power BI.")

@app.route("/bctc")
def bctc():
    ticker = request.args.get("ticker", default="HPG").upper()
    year_from = int(request.args.get("from", 2019))
    year_to = int(request.args.get("to", 2023))

    dfs = {}
    for k in STATEMENT_FILES:
        df = load_df(k)
        mask = (df["ticker"].str.upper() == ticker) & (df["year"].between(year_from, year_to))
        dfs[k] = df.loc[mask].sort_values("year")

    years_all = sorted(set(load_df("income_statement")["year"].tolist()))

    # Data for charts
    chart = {
        "years": [int(x) for x in dfs["income_statement"]["year"].tolist()],
        "revenue": [float(x) for x in dfs["income_statement"]["revenue"].tolist()],
        "net_profit": [float(x) for x in dfs["income_statement"]["net_profit"].tolist()],
    }

    return render_template(
        "bctc.html",
        ticker=ticker, year_from=year_from, year_to=year_to,
        years=years_all, tickers=list_tickers(),
        bs=dfs["balance_sheet"].to_dict(orient="records"),
        is_=dfs["income_statement"].to_dict(orient="records"),
        cf=dfs["cash_flow"].to_dict(orient="records"),
        chart=chart, title=f"BCTC {ticker}", meta_desc="Báo cáo tài chính: Cân đối, KQKD, Lưu chuyển."
    )

@app.route("/export/bctc/<kind>")
def export_bctc(kind):
    ticker = request.args.get("ticker","HPG").upper()
    year_from = int(request.args.get("from", 2019))
    year_to = int(request.args.get("to", 2023))
    if kind not in STATEMENT_FILES: return "Not found", 404
    df = load_df(kind)
    mask = (df["ticker"].str.upper()==ticker) & (df["year"].between(year_from, year_to))
    out = df.loc[mask].sort_values("year")
    buf = io.StringIO()
    out.to_csv(buf, index=False)
    buf.seek(0)
    return Response(buf.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={kind}_{ticker}_{year_from}-{year_to}.csv"})

# --------- SEO: RSS & sitemap ---------
@app.route("/rss.xml")
def rss():
    df = load_news().head(20)
    items = []
    for _, r in df.iterrows():
        items.append(f"<item><title>{r['title']}</title><link>{request.url_root}tin-tuc/{r['slug']}</link><pubDate>{r['date'].strftime('%a, %d %b %Y')}</pubDate><description>{r['excerpt']}</description></item>")
    xml = f'<?xml version="1.0" encoding="utf-8"?><rss version="2.0"><channel><title>{SITE_NAME}</title><description>{SITE_DESC}</description><link>{request.url_root}</link>{"".join(items)}</channel></rss>'
    return Response(xml, mimetype="application/rss+xml")

@app.route("/sitemap.xml")
def sitemap():
    pages = ["/", "/gioi-thieu", "/san-pham", "/tin-tuc", "/tuyen-dung", "/lien-he", "/bi", "/bctc"]
    xml_urls = "".join([f"<url><loc>{request.url_root.rstrip('/')}{p}</loc></url>" for p in pages])
    return Response(f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{xml_urls}</urlset>', mimetype="application/xml")

# ---------- auto open browser ----------
def open_browser():
    time.sleep(1.0)
    webbrowser.open("http://127.0.0.1:5000")

if __name__ == "__main__":
    threading.Thread(target=open_browser, daemon=True).start()
    print(">>> Flask starting at http://127.0.0.1:5000")
    app.run(debug=True)
