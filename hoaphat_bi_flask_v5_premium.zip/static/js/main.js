(function(){
  // Dark mode toggle
  const key = "hp-theme";
  const saved = localStorage.getItem(key) || "light";
  document.documentElement.setAttribute("data-theme", saved);
  const btn = document.getElementById("modeToggle");
  if(btn){
    btn.addEventListener("click", () => {
      const cur = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-theme", cur);
      localStorage.setItem(key, cur);
    });
  }

  // Finance chart
  if (window.__FIN_DATA__){
    try {
      const ctx = document.getElementById('finChart').getContext('2d');
      new Chart(ctx, {
        type: 'line',
        data: {
          labels: window.__FIN_DATA__.years,
          datasets: [
            { label: 'Doanh thu', data: window.__FIN_DATA__.revenue },
            { label: 'Lợi nhuận ròng', data: window.__FIN_DATA__.net_profit },
          ]
        },
        options: { responsive: true, tension: .3 }
      });
    } catch(e){ console.warn(e); }
  }
})();